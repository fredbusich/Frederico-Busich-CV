---
name: Modern Engineering Portfolio
colors:
  surface: '#f8f9ff'
  surface-dim: '#ccdbf4'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dde9ff'
  surface-container-highest: '#d5e3fd'
  on-surface: '#0d1c2f'
  on-surface-variant: '#45464f'
  inverse-surface: '#233144'
  inverse-on-surface: '#ebf1ff'
  outline: '#757680'
  outline-variant: '#c5c6d0'
  surface-tint: '#4d5c8f'
  primary: '#011445'
  on-primary: '#ffffff'
  primary-container: '#1a2a5a'
  on-primary-container: '#8392c9'
  inverse-primary: '#b5c4fe'
  secondary: '#006c47'
  on-secondary: '#ffffff'
  secondary-container: '#8af5be'
  on-secondary-container: '#00714b'
  tertiary: '#2b1200'
  on-tertiary: '#ffffff'
  tertiary-container: '#492300'
  on-tertiary-container: '#c2885b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b5c4fe'
  on-primary-fixed: '#051748'
  on-primary-fixed-variant: '#354476'
  secondary-fixed: '#8df7c1'
  secondary-fixed-dim: '#71dba6'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005235'
  tertiary-fixed: '#ffdcc4'
  tertiary-fixed-dim: '#fab988'
  on-tertiary-fixed: '#2f1400'
  on-tertiary-fixed-variant: '#683c15'
  background: '#f8f9ff'
  on-background: '#0d1c2f'
  surface-variant: '#d5e3fd'
typography:
  display:
    fontFamily: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.025em
  display-mobile:
    fontFamily: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  code:
    fontFamily: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
---

## Brand & Style

This design system expresses the visual identity of an early-career web developer: structured, precise, modern, and thoroughly professional. The design narrative rejects flashiness and synthetic decoration in favor of structural clarity, typographic hierarchy, and deliberate micro-interactions.

The aesthetic blends **Minimalism** and modern **Editorial SaaS**. Generous whitespace framing communicates confidence and technical discipline. Key structural surfaces utilize clean, low-contrast structural rules rather than heavy drop shadows, positioning the work directly at the center of attention.

The emotional target is immediate trust, technical capability, and deliberate craft. Prospective engineering managers, recruiters, and clients encounter an interface that feels fast, systematic, accessible, and free of clutter.

## Colors

The color palette prioritizes high-contrast legibility and crisp architectural boundaries:

- **Primary (`#1a2a5a`)**: Deep Navy. Serves as the bedrock for all primary headings, titles, prominent structural icons, and key visual weight anchors.
- **Secondary / Interactive (`#00875a`)**: Crisp Emerald Green. Reserved strictly for interactive states, text links, hover transitions, directional link arrows, active navigation indicators, and pill-badge accents.
- **Body & Structural Neutrals**:
  - `#0f172a`: High-emphasis title text.
  - `#334155`: Standard slate body text providing balanced contrast against light surfaces.
  - `#64748b`: Secondary metadata, timestamps, and subtitles.
  - `#94a3b8`: De-emphasized placeholder text and subtle icon fills.
- **Surfaces & Borders**:
  - `#ffffff`: Canvas background and primary foreground cards.
  - `#f8fafc`: Secondary sidebar panels, code snippets, and nested card fills.
  - `#f1f5f9`: Subdued hover states, badge fills, and structural table headers.
  - `#e2e8f0`: Delicate divider lines, card perimeters, and input boundaries.

## Typography

Typographic discipline provides the primary framework of this system. We standardize on **Inter** backed by the native operating system stack to ensure lightning-fast render performance and universal device familiarity.

- **Headlines**: Tight letter-spacing (`-0.01em` to `-0.025em`) paired with heavy `#1a2a5a` tint ensures authoritative visual hierarchy.
- **Body**: Regular weights at `15px` with generous `24px` line heights ensure long-form readability across project case studies, credentials, and curriculum vitae sections.
- **Labels & Badges**: Medium and Semibold weights (`500` and `600`) with positive letter-spacing (`0.01em` to `0.04em`) keep compact metadata legible in all caps or title case.
- **Monospace**: Clean monospace fallbacks (`ui-monospace`, `Menlo`, `Consolas`) applied strictly for git commit tags, tech-stack tags, and code blocks.

## Layout & Spacing

The layout model is anchored on an asymmetric **fixed-fluid hybrid grid**:

- **Desktop (>= 1024px)**: Dual-column application container capped at a maximum width of `1180px`. Left sidebar spans a fixed `320px` to `360px` for persistent personal profile information, availability status, and navigation, while the right main column expands dynamically across the remaining columns.
- **Tablet (768px - 1023px)**: Single column with `48px` outer margins. Content flows linearly: header profile first, followed by primary content cards with a 2-column project matrix.
- **Mobile (< 768px)**: Unified single column. Canvas margins clamp to `20px` (`1.25rem`), cards take 100% width, and nested elements collapse into vertical stacks.

Consistent application of empty space (`space-md`, `space-lg`, `space-xl`) sets a steady reading cadence, preventing information density from feeling suffocating.

## Elevation & Depth

This system avoids heavy drop shadows and faux-3D elevation. Depth is achieved via **tonal layering** and **low-contrast outlines**:

1. **Canvas Layer (`#ffffff`)**: The foundational base for reading and full-width flow.
2. **Surface Layer (`#f8fafc`)**: Nested background applied to the side navigation panel, metadata blocks, and code panels.
3. **Card Boundaries**: All floating or structured units use a `1px` continuous border in `#e2e8f0`.
4. **Interactive Hover Depth**: When hovering interactive cards or project modules, elevation is communicated by shifting the border color from `#e2e8f0` to `#cbd5e1` (or `#00875a` for primary clickable elements) paired with an ultra-soft, diffused shadow: `0 4px 12px -2px rgba(26, 42, 90, 0.05)`.

## Shapes

The shape system adopts a **Soft (`1`)** geometry profile:

- Standard components (buttons, input fields, interactive cards, preview panels) use `4px` (`0.25rem`) to `6px` radii. This evokes engineered precision rather than playful roundness.
- Larger groupings and modal surfaces step up to `8px` (`0.5rem`).
- The single exception is the **Pill Badge**, which uses full `9999px` rounded ends to clearly demarcate status flags, skill tags, and categorized metadata from structural actionable buttons.

## Components

### Buttons
- **Primary Outline Button**: Transparent fill, `1.5px` border in `#1a2a5a`, text in `#1a2a5a`. On hover: surface transitions to `#1a2a5a` with `#ffffff` text.
- **Secondary Accent Outline**: Transparent fill, `1.5px` border in `#00875a`, text in `#00875a`. On hover: surface transitions to `#00875a` with `#ffffff` text.
- **Tertiary / Ghost Button**: Transparent fill, `#334155` text. On hover: background `#f1f5f9`, text `#1a2a5a`.
- **Dimensions**: Vertical padding `8px`, horizontal padding `16px`, corner radius `4px`, font weight `500`.

### Chips & Badges
- **Skill Pill**: Background `#f8fafc`, `1px` border in `#e2e8f0`, text in `#334155` (`label-sm`).
- **Accent Badge (e.g., "Available for Hire")**: Background `#f0fdf4`, `1px` border in `#bbf7d0`, text in `#00875a`. Includes a small `6px` pulsating green dot.
- **Technology Tag**: Monospace font, background `#f1f5f9`, border `#e2e8f0`, text `#475569`.

### Interactive Text Links
- Set in `#00875a` with a medium weight (`500`).
- Display an inline directional arrow (`→` or `↗` for external links) that shifts `2px` along its axis on hover.
- Outlined bottom hover line transitions smoothly from `0%` to `100%` width.

### Cards & Project Items
- Background `#ffffff`, perimeter `1px solid #e2e8f0`, padding `24px` (`space-lg`), corner radius `6px`.
- Secondary header with project name in `#1a2a5a`, accompanied by date range and stack tags.
- Interactive cards subtly translate `-2px` on the Y-axis when hovered, revealing a delicate tint border (`#00875a` or `#cbd5e1`).

### Lists & Timeline (Experience / Education)
- Chronological timeline connected by a vertical `1px` hairline in `#e2e8f0`.
- Milestone nodes are `8px` hollow circles with a `2px` ring in `#00875a` on a white core.
- Section dates set in `#64748b` (`label-md`), role titles in `#1a2a5a` (`headline-sm`).

### Input Fields & Contact Elements
- Single-line inputs and textareas use white backgrounds, `1px solid #e2e8f0`, internal padding `10px 14px`, text `#334155`.
- Focus state: border shifts to `#00875a` with an ambient glow (`0 0 0 3px rgba(0, 135, 90, 0.12)`). No default browser outlines.